#ifndef DSPF_SP_CONVOL_ASM

#define DSPF_SP_CONVOL_ASM 1



void DSPF_sp_convol(double* input1, int size1, double* input2, int size2, double* output,int outputSize);


#endif
