#include "direction.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "DSPF_sp_convol.h"

double fs = 48000;
double x[512];
double y[512];
int main() {
    int m;
    int b = sizeof(x) / sizeof(x[0]);
    printf("b= %d\n",b);// Calculate the number of elements in the array
    int applied=5;
    for (m = 0; m < b; m++) {
        x[m] = (rand() % 100);
        x[m] = x[m]/1000;
    //    printf("x= %f \t  %d\n",x[m],m);
    }

    for (m = 0; m < b; m++) {
        if (m < applied) {
            y[m] = 0;
        } else {
            y[m] =x[m-applied];
        }
        // printf("y= %f \t  %d\n",y[m],m);
    }

//#include "L138_LCDK_aic3106_init.h"
//#define BUFSIZE 1024
//
//int32_t inbuffer_0[BUFSIZE]; // int32_t for TI Data Format
//int32_t inbuffer_1[BUFSIZE];
//int16_t buf_ptr_0 = 0;
//int16_t buf_ptr_1 = 0;
//
//int main(void)
//
//{
//  int16_t sample_data_0;
//  int16_t sample_data_1;
//  L138_initialise_poll(FS_24000_HZ,ADC_GAIN_0DB,DAC_ATTEN_0DB,LCDK_MIC_INPUT);
//  while(1)
//  {
//      sample_data_0 = input_left_sample();
//
//        inbuffer_0[buf_ptr_0] = sample_data_0;
//
//        buf_ptr_0 = (buf_ptr_0+1)%BUFSIZE;
//        output_left_sample(sample_data_0);
//
//        sample_data_1 = input_right_sample();
//        inbuffer_1[buf_ptr_1] = sample_data_1;
//        buf_ptr_1 = (buf_ptr_1+1)%BUFSIZE;
//        output_right_sample(sample_data_1);
//
//  }
//}
   // double a = direction(x, y, fs); // Assuming direction is a function declared in Direction.h
    double a;
   // a = demo(x, y, fs);
    a = direction(y, x, fs);
//    printf("%d\n", 9);
    printf("The value of the integer is: %f\n", a);
    printf("test_m");
    return 0;
}

    /**
     * main.c
     */
    //double x[513];
    //double y[513];
    //
    //// Declare the function
    //static void dataInput1();             // dummy function to be used with ProbePoint
    //static void dataInput2();
    //double fs= 48000;
    //void main()
    //{
    //  //puts("SineWave example started.\n");
    //
    //    while(1) // loop forever
    //    {
    //        /*  Read input data using a probe-point connected to a host file. */
    //       dataInput1();
    //       dataInput2();
    //    }
    //    double a= direction(x, y, fs);
    //    printf("%d",a);
    //}
    //
    ///*
    // * FUNCTION:     Read input signal and write processed output signal
    // *              using ProbePoints
    // * PARAMETERS: none.
    // * RETURN VALUE: none.
    // */
    //static void dataInput1()
    //{
    //   /* do data I/O */
    //    return;
    //}
    //static void dataInput2()
    //{
    //   /* do data I/O */
    //    return;
    //}

