#ifndef direction_H
#define direction_H

double direction(double *first_mic, double *second_mic, double fs);
// int max_find(double* input);
// void sort_descend(double *array, int *index, int n);

#endif