/*
 * direction.c
 *
 *  Created on: Feb 27, 2024
 *      Author: Krishan
 */
#include <direction.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <DSPF_sp_fftSPxSP.h>
#define PI 3.14159265358979
#define leng_s 600
double direction(double *first_mic, double *second_mic, double fs){
    double demonum;
    demonum=3;
    double d_micro=0.1;
    printf("%d\n", 9);
    double c=340;
    int i=0;

    int muestrasMAX = ceil(d_micro * fs/c);
    int desp = ceil(muestrasMAX * 1.5);
//    double delay_calculated = 0;
//    int leng_sig=sizeof(first_mic);
    int leng_sig=leng_s;
    double d[leng_s];
    double b_signal[leng_s];
//    while(i<leng_sig){
//        d[i]=0;
//    //          b_signal[i]=0;
//              printf("%d\\ %f\n",i, d[i]);
//              i++;
//    }
//    for (i=0;i<leng_sig;i++){
//        d[i]=0;
//        b_signal[i]=0;
//        printf("%d\n",i);
//    }
    printf("size %d\n", sizeof(b_signal));
//    double* d = malloc(leng_sig* sizeof(double));
//    double* b_signal = malloc(leng_sig* sizeof(double));
//    double d[leng_sig];
//    double b_signal[leng_sig];
//    double* b_signal = NULL;
//         for(i=0; i<leng_sig; i++){
//                 b_signal[i]=0;
//                 d[i]=0;
//
//             }

    double M3=0;
    printf("inside %d\n", leng_sig);
    // tic; measure of time tic toc
    int k=0,b_k=0;
    int g=0;
//    int zz=0;
//    int sss=513;
//    double tmp[sss];

//    for(zz=0;zz<leng_sig;zz++){
//        tmp[zz]=second_mic[zz];
//        printf("b_signal: %f \t second_mic: %f \t  \n", tmp[zz],second_mic[zz]);
//    }
    for (g = 0; g < leng_sig; g=g+2){
        printf("%d/%d\n",g,leng_sig);
////        printf("%f\n",first_mic[k]);
//       // if (first_mic[k]>=0){
////        if(k==60){
////            int pp=2;
////            printf("try\n");
////        }
//         printf("test1\n");
        d[g] = first_mic[g];
//        //}
//        //else{
//         //   d[k]=-first_mic[k];
//        //}
//
        if (second_mic[g]>=0){
                      b_signal[g] = second_mic[g];}
         else {
                      b_signal[g]=0-second_mic[g];
                  }

////        printf("%d\n",kk);
//                     printf("b_signal: %f \t second_mic: %f \n", b_signal[k],second_mic[k]);
    }
    printf("test1/ %d\n",g);
    int kk=0;
    for (kk = 0; kk < 513; kk++){
         if (second_mic[kk]>=0){
             b_signal[kk] = second_mic[kk];
//             double temp=second_mic[k];
//             b_signal[k]=temp;
         }
         else{
             b_signal[kk]=-second_mic[kk];
         }
//         printf("%d\n",kk);
//             printf("b_signal: %f \t second_mic: %f \n", b_signal[k+1],second_mic[k+1]);
    }
    printf("for done");


    double maxnum1=d[max_find(d)];
    double maxnum2=b_signal[max_find(b_signal)];
    if (maxnum1>=maxnum2){
        M3 = maxnum1;
    }
    else{
        M3=maxnum2;}

//    for(i=0; i<60; i++){
//                            printf("the value of h1 %f\n", b_signal[i]);
//                        }
      /*  Normalization value */
      /*  Normalizing%I made m3*2 to m3. */
    for (b_k = 0; b_k < leng_sig; b_k++){
        b_signal[b_k] = (first_mic[b_k]*2.0 );
                b_signal[b_k]=b_signal[b_k]/ (M3);
        d[b_k] = (second_mic[b_k]*2.0 );
                d[b_k]=d[b_k]/ (M3) ;
    }

    printf("the value of h1 %f\n",100);
//    for(i=0; i<60; i++){
//                        printf("the value of h1 %f\n", first_mic[i]);
//                    }

    double* hDESp = (double*)calloc(desp, sizeof(double));
//    double hDESp[desp];   // index
    for(i=0; i<desp; i++){
        hDESp[i]=0;
    }

    hDESp[desp]=1;


//     int nh=leng_sig;
//     int nr=desp+leng_sig-1;
     int outputSize = desp + leng_sig - 1;
//

     double* d1 = NULL;
//     double* dev = (double*)malloc(leng_sig * sizeof(double));
//     double* d1 = (double*)calloc(outputSize, sizeof(double));
     for(i=0; i<outputSize; i++){
             d1[i]=0;
         }
//     free(hDESp);


//     double d1[outputSize];
     DSPF_sp_convol(hDESp, desp, second_mic, leng_sig, d1,outputSize);
     int p=60;
     double mu=0.0117;
     double* h0 = NULL;// (double*)malloc(p * sizeof(double));
     for(i=0; i<p; i++){
                 h0[i]=0;
             }
     double* h = NULL;// (double*)malloc(p * sizeof(double));
     for(i=0; i<p; i++){
                 h[i]=0;
             }
    // double* h0 = (double*)malloc(p * sizeof(double));
    // double* h = (double*)malloc(p * sizeof(double));
//     double h0[p],h[p];
     int j=0;
     for (j=0; j<p; j++){
         h0[j]=0;
         h[j]=0;
     }


     double N1=sizeof(b_signal);

     double* xx = NULL;//(double*)malloc(p * sizeof(double));
     for(i=0; i<p; i++){
                 xx[i]=0;
             }
     double xtmp_im=0;
     for (k = 0; k < leng_sig-p+1; k++) {
         /*  Last p inputs x[k], x[k-1], ... x[k-p] */
         double M3 = 0.0;
         for (b_k = 0; b_k < p; b_k++) {

           xtmp_im = b_signal[(k - b_k) + p-1];
           xx[b_k] = xtmp_im;
           M3 += xtmp_im * h[b_k];
         }
         /*  Filter output: x*h Convolution */
         /*  Error */
         M3 = mu * (d1[k + p-1] - M3);
         for (b_k = 0; b_k < p; b_k++) {
           h[b_k] += M3 * xx[b_k];
         }
         /*  We update the filter coefficients. */
       }

     double* h1 =NULL;// (double*)malloc(p * sizeof(double));
//     double h1[p];
     for(i=0; i<p; i++){
                 h1[i]=0;
             }
     for (j=0; j<desp-muestrasMAX-3; j++){
           h1[j]=0;
        }
     for (j=desp-muestrasMAX-3; j<p; j++){
               h1[j]=h[j];
         }
     for(j=desp+muestrasMAX+1;j<sizeof(h1);j++){////forloop dout +1.+2
         h1[j]=0;
     }
     h1[desp]=h1[desp]/2;

     double maxnum3 = h1[0];
     int z=0;
     double location=0;

         for (z = 1; z < sizeof(h1); z++)
         {
             if (h1[z] > maxnum3)
             {
                     maxnum3  = h1[z];
                     location=z;

             }
         }

     location=location-desp-1;


     //return location;
   /*  void sort_descend(double *array, int *index, int n) {
         // Initialize index array
         for (int i = 0; i < n; ++i) {
             index[i] = i;
         }

         // Perform bubble sort in descending order
         for (int i = 0; i < n - 1; ++i) {
             for (int j = 0; j < n - i - 1; ++j) {
                 if (array[j] < array[j + 1]) {
                     // Swap elements in array
                     double temp = array[j];
                     array[j] = array[j + 1];
                     array[j + 1] = temp;

                     // Swap corresponding indices
                     int temp_index = index[j];
                     index[j] = index[j + 1];
                     index[j + 1] = temp_index;
                 }
             }
         }
     }
*/
    // int main() {
        // double array[] = {9.2, 5.4, 7.8, 3.6, 1.0};
//         int n = sizeof(h1) / sizeof(h1[0]);
//
//         // Allocate memory for index array
//         int *index = (int *)malloc(n * sizeof(int));
//         if (index == NULL) {
//             printf("Memory allocation failed!\n");
//             return 1;
//         }

         // Sort array in descending order and get indices
//         sorting(array, index, n);//it is decsending
         int h_9=128; // Size of the FFT
//         double q[h_9];
         //fft
         float *x,*w,*q;
         // input for fft
         x = NULL; //calloc(2 * sizeof(float), 2*h_9);
         for(i=0; i<2*h_9; i++){
                          x[i]=0;
                      }
         for(i=0;i<2*h_9;i++){
             if(i<120){
                 x[i]=h1[i/2];
                 i=i+1;
                 x[i]=0.0;

             }
             else{
                 x[i]=0.0;
             }
         }

         w = NULL;// calloc(2 * sizeof(float), 2*h_9);   // twiddle factors
         for(i=0; i<2*h_9; i++){
                        w[i]=0;
                    }
         int u= gen_twiddle(w, 2*h_9);
         q= NULL;//calloc(2 * sizeof(float), 2*h_9);
         for(i=0; i<2*h_9; i++){
                         q[i]=0;
                      }
         // Output sequence, assuming interleaved real and imaginary parts
         unsigned char brev[64] = {
            0x0, 0x20, 0x10, 0x30, 0x8, 0x28, 0x18, 0x38,
            0x4, 0x24, 0x14, 0x34, 0xc, 0x2c, 0x1c, 0x3c,
            0x2, 0x22, 0x12, 0x32, 0xa, 0x2a, 0x1a, 0x3a,
            0x6, 0x26, 0x16, 0x36, 0xe, 0x2e, 0x1e, 0x3e,
            0x1, 0x21, 0x11, 0x31, 0x9, 0x29, 0x19, 0x39,
            0x5, 0x25, 0x15, 0x35, 0xd, 0x2d, 0x1d, 0x3d,
            0x3, 0x23, 0x13, 0x33, 0xb, 0x2b, 0x1b, 0x3b,
            0x7, 0x27, 0x17, 0x37, 0xf, 0x2f, 0x1f, 0x3f
         };
         int n_min = 2;  // Minimum FFT size
         int offset = 0;  // Offset in the twiddle factor array
         int n_max = 128;  // Maximum FFT size

         // Call the DSPF_sp_fftSPxSP function
         DSPF_sp_fftSPxSP(h_9, x, w, q, brev, n_min, offset, n_max);

//         double* q = (double*)malloc((2*h_9) * sizeof(double));

//         double M[h_9-1];
         double* M = NULL;//(double*)malloc((2*(h_9-1)) * sizeof(double));

         for(i=0; i<2*(h_9-1); i++){
                             M[i]=0;
                         }
         for(z=0;z<sizeof(M);z++){
           M[z]=q[z+2]-q[z];
           M[z+1]=q[z+3]-q[z+1];
           z=z+1;

         }
          i=0;
             double tempm,tempm2;

             // Calculate the midpoint
             int mid = sizeof(M) / 4;

             // Perform the shift
             for (i = 0; i < mid; i++) {
                 tempm = M[i];
                 tempm2= M[i+1];
                 M[i] = M[i + mid];
                 M[i+1] = M[i + mid+1];
                 M[i + mid] = tempm;
                 M[i+mid+1]=tempm2;
             }

         i=0;
         float *angle;
         angle = NULL;//calloc(sizeof(float), (sizeof(M)/2));
         for(i=0;i<sizeof(M)/2;i++){
             angle[i]=atan2(M[1+i], M[i]);
             i=i+1;

         }
         //double phase_array[] = {0.0, 1.5 * PI, 2.5 * PI, -2.0 * PI, 3.0 * PI};
             int lengt_h = sizeof(angle) / sizeof(angle[0]);

             // Set the jump threshold (π radians)
             double jump_threshold = PI;

             // Unwrap the phase array
             unwrap(angle, lengt_h, jump_threshold);
             //M1=angle






         double M1=sizeof(M)+2;
         int p1=floor(M1/2-2);
         int p2=ceil(M1/2+2);
         int o=0;
         double K=0;
         for(o=p1-1;o<p2;o++){
             K=K+M[o];

         }
         K=K/(p2-p1+1);
         double Nprime;
         double N;
         Nprime=(-K*h_9/(2*3.14));
         if(Nprime<0){
            N=Nprime+h_9;
            N=N-desp;
         }
         else{
             N=round(Nprime);
             N=N-desp;
         }
         double delay;
         delay=N/fs;




         // Free dynamically allocated memory
//         free(index);
         return location;
    return 1;
}




