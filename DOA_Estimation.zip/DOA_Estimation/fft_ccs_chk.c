#include "direction.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "DSPF_sp_convol.h"
#include "DSPF_sp_fftSPxSP.h"
#include "twiddle_factor_gen.h"
/**
 * main.c
 */

int main() {
    // Example values
    int N = 8;  // Size of the FFT
    int N_o= 2*N;
    float *w;
    float x[] = {1.0,0.0, 2.0,0.0, 3.0,0.0, 4.0,0.0, 0.0,0.0, 0.0,0.0, 0.0,0.0, 0.0,0.0};  // Input sequence
//    float w[] = {1.0,0.0, 0.7071,- 0.7071, 0.0,-1.0, -0.7071,- 0.7071, -1.0,0.0, -0.7071, 0.7071, 0.0,1.0, 0.7071, 0.7071};  // Twiddle factors
    w = calloc(2 * sizeof(float), 2*N);
    int u= gen_twiddle(w, N);
    float *y;
    y=calloc(2 * sizeof(float), 2*N);  // Output sequence, assuming interleaved real and imaginary parts
//    unsigned char brev[] = {0, 4, 2, 6, 1, 5, 3, 7};  // Bit-reversed index array
    unsigned char brev[64] = {
       0x0, 0x20, 0x10, 0x30, 0x8, 0x28, 0x18, 0x38,
       0x4, 0x24, 0x14, 0x34, 0xc, 0x2c, 0x1c, 0x3c,
       0x2, 0x22, 0x12, 0x32, 0xa, 0x2a, 0x1a, 0x3a,
       0x6, 0x26, 0x16, 0x36, 0xe, 0x2e, 0x1e, 0x3e,
       0x1, 0x21, 0x11, 0x31, 0x9, 0x29, 0x19, 0x39,
       0x5, 0x25, 0x15, 0x35, 0xd, 0x2d, 0x1d, 0x3d,
       0x3, 0x23, 0x13, 0x33, 0xb, 0x2b, 0x1b, 0x3b,
       0x7, 0x27, 0x17, 0x37, 0xf, 0x2f, 0x1f, 0x3f
    };
    int n_min = 2;  // Minimum FFT size
    int offset = 0;  // Offset in the twiddle factor array
    int n_max = 8;  // Maximum FFT size

    // Call the DSPF_sp_fftSPxSP function
    DSPF_sp_fftSPxSP(N, x, w, y, brev, n_min, offset, n_max);

    // Print the result (assuming interleaved real and imaginary parts)
    printf("FFT Result:\n");
    int i = 0;
    for (i = 0; i < 2 * N; i += 2) {
        printf("%f + j%f\n", y[i], y[i + 1]);
    }
    printf("twiddle:\n");
//        int i = 0;
        for (i = 0; i < 2*N; i += 1) {
            printf("%f \n", w[i]);
        }
    printf("%d",u);

    return 0;
}
