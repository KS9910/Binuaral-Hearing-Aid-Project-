#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "DSPF_sp_convol.h"

#include <stdio.h>

void DSPF_sp_convol(double* input1, int size1, double* input2, int size2, double* output, int outputSize) {
    // Ensure the output array is large enough

    int i=0;
    // Initialize output array to zero
    for ( i = 0; i < outputSize; i++) {
        output[i] = 0;
    }
    int j=0;

    // Perform convolution
    for (i = 0; i < size1; i++) {
        for (j = 0; j < size2; j++) {
            output[i + j] += input1[i] * input2[j];
        }
    }
}
