#ifndef TWIDDLE_FACTOR_GEN_H

#define TWIDDLE_FACTOR_GEN_H


int gen_twiddle(float *w, int n);


#endif