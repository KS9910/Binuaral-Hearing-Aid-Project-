#include "direction.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "DSPF_sp_convol.h"
#include "DSPF_sp_fftSPxSP.h"
#include "twiddle_factor_gen.h"

int main() {
    // const int N = 4; // Example array size
    // float x[N] ; // Example input array
    // for(int i=0; i<N; i++){
    //     x[i]=i;
    // }
    // float y[N]; // Array to store the DFT result

    // // Call the DFT function
    // dft(N, x, y);

    // // Print the result 
    // printf("DFT Result:\n");
    // for (int i = 0; i < N; i++) {
    //     printf("y[%d] = %.2f\n", i, y[i]);
    // }

 int h_9=8; // Size of the FFT
 int p=4;
//         double q[h_9];
         //fft
        //  float *x,*w,*q;
         // input for fft
        //  x = NULL; //calloc(2 * sizeof(float), 2*h_9);
        float x[h_9];
        // float x[h_9],M[2*h_9];
        float *w, *M;
        w = calloc(2 * sizeof(float), 2*h_9);
        M = calloc(2 * sizeof(float), 2*h_9);
        //  for(i=0; i<2*h_9; i++){
        //                   x[i]=0;
        //               }
        int i;
        // for(i=0;i<h_9;i++){
        //     if(i<p){
        //         x[i]=i;
        //     }
        //     else x[i]=0;
        // }
         for(i=0;i<2*h_9;i++){
             if(i<2*p){
                if(i%2==0){
                    int temp_1=i/2;
                    x[i]=i;
                }
                else x[i]=0;
                printf("x is %d \t %f\n", i, x[i]);

             }
             else{
                 x[i]=0.0;
                 printf("x is %d \t %f\n", i, x[i]);
             }
         }

        // using th dft function
        // dft(h_9, x, M);
       //  w = NULL;// calloc(2 * sizeof(float), 2*h_9);   // twiddle factors
        //  for(i=0; i<2*h_9; i++){
        //                 w[i]=0;
        //             }
         int u= gen_twiddle(w, h_9);
        //  q= NULL;//calloc(2 * sizeof(float), 2*h_9);
        //  for(i=0; i<2*h_9; i++){
        //                  q[i]=0;
        //               }
         // Output sequence, assuming interleaved real and imaginary parts
         unsigned char brev[64] = {
            0x0, 0x20, 0x10, 0x30, 0x8, 0x28, 0x18, 0x38,
            0x4, 0x24, 0x14, 0x34, 0xc, 0x2c, 0x1c, 0x3c,
            0x2, 0x22, 0x12, 0x32, 0xa, 0x2a, 0x1a, 0x3a,
            0x6, 0x26, 0x16, 0x36, 0xe, 0x2e, 0x1e, 0x3e,
            0x1, 0x21, 0x11, 0x31, 0x9, 0x29, 0x19, 0x39,
            0x5, 0x25, 0x15, 0x35, 0xd, 0x2d, 0x1d, 0x3d,
            0x3, 0x23, 0x13, 0x33, 0xb, 0x2b, 0x1b, 0x3b,
            0x7, 0x27, 0x17, 0x37, 0xf, 0x2f, 0x1f, 0x3f
         };
         int n_min = 2;  // Minimum FFT size
         int offset = 0;  // Offset in the twiddle factor array
         int n_max = 8;  // Maximum FFT size

         // Call the DSPF_sp_fftSPxSP function
         DSPF_sp_fftSPxSP(h_9, x, w, M, brev, n_min, offset, n_max);

        // Print the result 
   printf("FFT Result:\n");
    
    for (i = 0; i < 2 * h_9; i += 2) {
        printf("%f + j%f\n", M[i], M[i + 1]);
    }
    printf("twiddle:\n");
//        int i = 0;
        for (i = 0; i < 2*h_9; i += 1) {
            printf("%f \n", w[i]);
        }
    printf("%d",u);
    return 0;
}