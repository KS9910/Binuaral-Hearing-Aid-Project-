DZ
/*
 * direction.c
 *
 *  Created on: Feb 27, 2024
 *      Author: Krishan
 */
#include "direction.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "DSPF_sp_fftSPxSP.h"
#include "DSPF_sp_convol.h"
#include "max_find.h"
#include "twiddle_factor_gen.h"
#include "unwraper.h"

#define PI 3.14159265358979
double direction(double *first_mic, double *second_mic, double fs){
    double d_micro=0.1;
    double c=340;
    int i=0;
    int muestrasMAX = ceil(d_micro * fs/c);
    int desp = ceil(muestrasMAX * 1.5);
    printf("desp is: %d\n",desp);
//    int leng_sig=sizeof(first_mic)/sizeof(first_mic[0]);
    int leng_sig=512;
    double d[leng_sig];
    double b_signal[512];

    double M3;
    // tic; measure of time tic toc
    int k,kk,b_k;
//    int zz=0;
//    int sss=513;
//    double tmp[sss];

//    for(zz=0;zz<leng_sig;zz++){
//        tmp[zz]=second_mic[zz];
//        printf("b_signal: %f \t second_mic: %f \t  \n", tmp[zz],second_mic[zz]);
//    }
    for (k = 0; k < leng_sig; k++){
        // printf("%d/%d\n",k,leng_sig);
        // printf("%f\n",first_mic[k]);
        if (first_mic[k]>=0){
        //  printf("test1");
        d[k] = first_mic[k];
        }
        else{
           d[k]=-first_mic[k];
        }

        if (second_mic[k]>=0){
                      b_signal[k] = second_mic[k];}
         else {
                      b_signal[k]=-second_mic[k];
                  }

//        printf("%d\n",kk);
                    //  printf("b_signal: %f \t second_mic: %f \n", b_signal[k], second_mic[k]);
    }
//     for (kk = 0; kk < 513; kk++){
//          if (second_mic[kk]>=0){
//              b_signal[kk] = second_mic[kk];
// //             double temp=second_mic[k];
// //             b_signal[k]=temp;
//          }
//          else{
//              b_signal[kk]=-second_mic[kk];
//          }
//         printf("%d\n",kk);
            // printf("b_signal: %f \t second_mic: %f \n", b_signal[k+1],second_mic[k+1]);
    
    // printf("for done");

    int max_indx1=max_find(d,leng_sig) ;
    int max_indx2=max_find(b_signal,leng_sig);
    double maxnum1=d[max_indx1];
    double maxnum2=b_signal[max_indx2];
    if (maxnum1>=maxnum2){
        M3 = maxnum1;
    }
    else{
        M3=maxnum2;}

    printf("m is %f\n",M3);

//    for(i=0; i<60; i++){
//                            printf("the value of h1 %f\n", b_signal[i]);
//                        }
      /*  Normalization value */
      /*  Normalizing%I made m3*2 to m3. */
    for (b_k = 0; b_k < leng_sig; b_k++){
        b_signal[b_k] = (second_mic[b_k]*2.0 );
                b_signal[b_k]=b_signal[b_k]/ (M3);
                // printf("b_signal: %f \n ", b_signal[b_k]);
        d[b_k] = (first_mic[b_k]*2.0 );
                d[b_k]=d[b_k]/ (M3) ;
    }

// int temp_chk= max_find(b_signal, leng_sig);
// printf("max_after normalize %f\n", b_signal[temp_chk]);

    
//    for(i=0; i<60; i++){
//                        printf("the value of h1 %f\n", first_mic[i]);
//                    }

    // double* hDESp = (double*)calloc(desp, sizeof(double));
   double hDESp[desp+1];   // index
    for(i=0; i<desp; i++){
        hDESp[i]=0;
    }

    hDESp[desp]=1;


//     int nh=leng_sig;
//     int nr=desp+leng_sig-1;
     int outputSize = desp + leng_sig ;


    //  double* d1 = NULL;
    double d1[outputSize];
//     double* dev = (double*)malloc(leng_sig * sizeof(double));
//     double* d1 = (double*)calloc(outputSize, sizeof(double));
    //  for(i=0; i<outputSize; i++){
    //          d1[i]=0;
    //      }
//     free(hDESp);


//     double d1[outputSize];
     DSPF_sp_convol(hDESp, desp+1 , d, leng_sig, d1,outputSize);
    // DSPF_sp_convol(hDESp, desp+1 , b_signal, leng_sig, d1,outputSize);
       for (int i=0; i<outputSize; i++){
    printf("d1 is %f /%d\n", d1[i],i);
}
printf("d1 length: %d\n", outputSize);
     int p=60;
     double mu=0.0117;
    //  double* h0 = NULL;// (double*)malloc(p * sizeof(double));
    double h0[p];
    double h[p];
     for(i=0; i<p; i++){
                 h0[i]=0;
                 h[i]=0;
             }
    //  double* h = NULL;// (double*)malloc(p * sizeof(double));
    
    //  for(i=0; i<p; i++){
    //              h[i]=0;
    //          }
    // double* h0 = (double*)malloc(p * sizeof(double));
    // double* h = (double*)malloc(p * sizeof(double));
//     double h0[p],h[p];
  
     int N1=sizeof(b_signal)/sizeof(b_signal[0]);
     printf("n is %d\n",N1);
     double xx[p],y_c[N1];
    //    for(int a=0;a<N1;a++){
    //         y_c[a]=0;
            
    //     }
     int t = p-1;
     while(t<N1){
        // printf("k is %d\n", t);
        for(int a=0;a<p;a++){
            xx[a]=b_signal[t-a];
            
        }
        double temp_y=0.0;
        for(int a=0;a<p;a++){
           
            temp_y += xx[a]*h[a]; 
            // printf("e is %f\n",temp_y);
        }
        // printf("d1[k] %f\n", d1[k]);
        y_c[t]=temp_y;
        double e = d1[t]-temp_y;
        // printf("e is %f\n",e);
        for(int a=0; a<p ;a++){
            h[a] = h[a] + mu*e*xx[a];
            // printf("test_xx %f\n", h[a]);
        }
        t++;
     }
// for (i=0; i<N1; i++){
//     printf("h is %f /%d\n", y_c[i],i);
// }
//     //  double* xx = NULL;//(double*)malloc(p * sizeof(double));
    
    //  for(i=0; i<p; i++){
    //              xx[i]=0;
    //          }
    //  double xtmp_im=0;
    //  for (k = 0; k < leng_sig-p+1; k++) {
    //      /*  Last p inputs x[k], x[k-1], ... x[k-p] */
    //      double M3 = 0.0;
    //      for (b_k = 0; b_k < p; b_k++) {

    //        xtmp_im = b_signal[(k - b_k) + p-1];
    //        xx[b_k] = xtmp_im;
    //        M3 += xtmp_im * h[b_k];
    //      }
    //      /*  Filter output: x*h Convolution */
    //      /*  Error */
    //      M3 = mu * (d1[k + p-1] - M3);
    //      for (b_k = 0; b_k < p; b_k++) {
    //        h[b_k] += M3 * xx[b_k];
    //      }
    //      /*  We update the filter coefficients. */
    //    }

    //  double* h1 =NULL;// (double*)malloc(p * sizeof(double));

    double h1[p];
    //  for(i=0; i<p; i++){
    //              h1[i]=0;
    //          }
    int j;
     for (j=0; j<desp-muestrasMAX-3; j++){
           h1[j]=0;
        }
     for (j=desp-muestrasMAX-3; j<p; j++){
               h1[j]=h[j];
         }
     for(j=desp+muestrasMAX+1;j<(sizeof(h1)/sizeof(h1[0]));j++){////forloop dout +1.+2
         h1[j]=0;
     }
     h1[desp]=h1[desp]/2;

     double maxnum3 = h1[0];
     int z=0;
     int location=0;

         for (z = 1; z < (sizeof(h1)/sizeof(h1[0])); z++)
         {
             if (h1[z] > maxnum3)
             {
                     maxnum3  = h1[z];
                     location=z;
             }
         }

     location=location-desp;

    //     for (i=0; i<p; i++){
    //     printf("h1 is %f\n", h1[i]);
    // }
         int h_9=128; // Size of the FFT
        float x[2*h_9],q[h_9-1];
        // float x[h_9],M[2*h_9];
        float *w, *M;
        w = calloc(2 * sizeof(float), 2*h_9);
        M = calloc(2 * sizeof(float), 2*h_9);
        //  for(i=0; i<2*h_9; i++){
        //                   x[i]=0;
        //               }

         for(i=0;i<2*h_9;i++){
             if(i<2*p){
                if(i%2==0){
                    int temp_1=i/2;
                    x[i]=h1[temp_1];
                }
                else x[i]=0;
                // printf("x is %d \t %f\n", i, x[i]);
             }
             else{
                 x[i]=0.0;
             }
         }

        // using th dft function
        // dft(h_9, x, M);
       //  w = NULL;// calloc(2 * sizeof(float), 2*h_9);   // twiddle factors
        //  for(i=0; i<2*h_9; i++){
        //                 w[i]=0;
        //             }
         int u= gen_twiddle(w, h_9);
        //  q= NULL;//calloc(2 * sizeof(float), 2*h_9);
        //  for(i=0; i<2*h_9; i++){
        //                  q[i]=0;
        //               }
         // Output sequence, assuming interleaved real and imaginary parts
         unsigned char brev[64] = {
            0x0, 0x20, 0x10, 0x30, 0x8, 0x28, 0x18, 0x38,
            0x4, 0x24, 0x14, 0x34, 0xc, 0x2c, 0x1c, 0x3c,
            0x2, 0x22, 0x12, 0x32, 0xa, 0x2a, 0x1a, 0x3a,
            0x6, 0x26, 0x16, 0x36, 0xe, 0x2e, 0x1e, 0x3e,
            0x1, 0x21, 0x11, 0x31, 0x9, 0x29, 0x19, 0x39,
            0x5, 0x25, 0x15, 0x35, 0xd, 0x2d, 0x1d, 0x3d,
            0x3, 0x23, 0x13, 0x33, 0xb, 0x2b, 0x1b, 0x3b,
            0x7, 0x27, 0x17, 0x37, 0xf, 0x2f, 0x1f, 0x3f
         };
         int n_min = 2;  // Minimum FFT size
         int offset = 0;  // Offset in the twiddle factor array
         int n_max = 128;  // Maximum FFT size

         // Call the DSPF_sp_fftSPxSP function
         DSPF_sp_fftSPxSP(h_9, x, w, M, brev, n_min, offset, n_max);
  
        // printf("FFT Result:\n");
    
        // for (i = 0; i < 2 * h_9; i += 2) {
        //     printf("%f + j%f\n", M[i], M[i + 1]);
        // }
        // double* q = (double*)malloc((2*h_9) * sizeof(double));

        // double M[h_9-1];
        //  double* M = NULL;//(double*)malloc((2*(h_9-1)) * sizeof(double));
        // double M[2*(h_9-1)];
        //  for(i=0; i<2*(h_9-1); i++){
        //                      M[i]=0;
        //                  }
        //  for(z=0;z<(sizeof(M)/sizeof(M[0]));z++){
        //    M[z]=q[z+2]-q[z];
        //    M[z+1]=q[z+3]-q[z+1];
        //    z=z+1;

        //  }
          
             double tempm,tempm2;

             // Calculate the midpoint
             int mid = (2*h_9)/2;// / 4;
// printf("mid %d\n", mid);
             // Perform the shift
             for (i = 0; i < mid; i++) {
                 tempm = M[i];
                 tempm2= M[i+1];
                 M[i] = M[i + mid];
                 M[i+1] = M[i + mid+1];
                 M[i + mid] = tempm;
                 M[i+mid+1]=tempm2;
             }

        //  double *angle;
        //  angle = NULL;//calloc(sizeof(float), (sizeof(M)/2));
        // int var2 =(sizeof(M)/sizeof(M[0]));
        printf("var2 %d\n", mid);
        double angle[mid];
         for(int i=0;i<mid;i++){
            printf("test23\n");
             angle[i]=atan2(M[1+i], M[i]);
            //  printf("angle is %f\n", angle[i]);
             i=i+1;
         }
        
         //double phase_array[] = {0.0, 1.5 * PI, 2.5 * PI, -2.0 * PI, 3.0 * PI};
             int lengt_h = sizeof(angle) / sizeof(angle[0]);

             // Set the jump threshold (π radians)
             double jump_threshold = PI;

             // Unwrap the phase array
             unwrap(angle, lengt_h, jump_threshold);
             //M1=angle

       
       
         for(z=0;z<(sizeof(q)/sizeof(q[0]));z++){
           q[z]=angle[z+1]-angle[z];
        //    q[z+1]=angle[z+3]-angle[z+1];
        //    z=z+1;

         }




         double M1=(sizeof(q)/sizeof(q[0]))+2;
         int p1=floor((M1/2)-2);
         int p2=ceil((M1/2)+2);
         int o=0;
         double K=0;
         for(o=p1-1;o<p2;o++){
             K=K+q[o];

         }
         K=K/(p2-p1+1);
         double Nprime;
         double N;
         Nprime=(-K*h_9/(2*3.14));
         if(Nprime<0){
            N=round(Nprime+h_9);
            N=N-desp;
         }
         else{
             N=round(Nprime);
             N=N-desp;
         }
         double delay;
         delay=N/fs;




         // Free dynamically allocated memory
//         free(index);
 printf("N: %f\n", N);
 printf("location: %d\n", location);
         return delay;
    // return 1;
}




