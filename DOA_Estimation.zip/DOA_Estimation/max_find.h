#ifndef MAX_FIND_H

#define MAX_FIND_H

int max_find(double* input, int size);

#endif