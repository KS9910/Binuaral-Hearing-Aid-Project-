#ifndef DSPF_SP_FFTSPXSP_H_
#define DSPF_SP_FFTSPXSP_H_ 1

void DSPF_sp_fftSPxSP
(
    int N,
    float * ptr_x,
    float * ptr_w,
    float * ptr_y,
    unsigned char * brev,
    int n_min,
    int offset,
    int n_max
);

void dft(int N, float x[], float y[]);

#endif