#include "direction.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int max_find(double* input, int size) {
    int location = 0;
    double maxnum = input[0];

    for (int z = 1; z < size; z++) {
        if (input[z] > maxnum) {
            maxnum = input[z];
            location = z;
        }
    }

    return location;
}

