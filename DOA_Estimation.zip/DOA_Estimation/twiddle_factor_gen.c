#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "DSPF_sp_fftSPxSP.h"

#ifndef PI
# ifdef M_PI
#  define PI M_PI
# else
#  define PI 3.14159265358979323846
# endif
#endif


int gen_twiddle(float *w, int n)
{
    int i, j, k;

    for (j = 1, k = 0; j < n >> 2; j = j << 2)
    {
        for (i = 0; i < n >> 2; i += j)
        {
            w[k +  5] =  sin(6.0 * PI * i / n);
            w[k +  4] =  cos(6.0 * PI * i / n);

            w[k +  3] =  sin(4.0 * PI * i / n);
            w[k +  2] =  cos(4.0 * PI * i / n);

            w[k +  1] =  sin(2.0 * PI * i / n);
            w[k +  0] =  cos(2.0 * PI * i / n);

            k += 6;
        }
    }

    return k;
}
