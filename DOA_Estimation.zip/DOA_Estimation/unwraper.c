/*
 * unwraper.c
 *
 *  Created on: Feb 29, 2024
 *      Author: Krishan
 */
#include <stdio.h>
#define PI 3.14159265358979
void unwrap(double *array, int length, double jump_threshold) {
    // Loop through the array
    int i;
    for ( i = 1; i < length; i++) {
        // Calculate phase difference
        double diff = array[i] - array[i - 1];

        // Check if the difference exceeds jump threshold
        if (diff >= jump_threshold) {
            int num_wraps = (int)(diff / (2 * PI));
            array[i] -= num_wraps * 2 * PI;
        } else if (diff <= -jump_threshold) {
            int num_wraps = (int)(diff / (2 * PI));
            array[i] -= num_wraps * 2 * PI;
        }
    }
}



