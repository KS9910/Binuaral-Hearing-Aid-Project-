#ifndef UNWRAPER_H

#define UNWRAPER_H



void unwrap(double *array, int length, double jump_threshold);


#endif